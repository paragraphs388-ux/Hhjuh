CACH 1 - Android Studio: File > Open thu muc VideoJoiner, doi Gradle sync, Build > Build APK(s).
CACH 2 - GitHub (khong can may tinh manh): tao repo, upload toan bo thu muc nay,
vao tab Actions > Build APK > Run workflow, tai app-debug.apk o muc Artifacts.
