package com.example.videojoiner

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Matrix
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.effect.MatrixTransformation
import androidx.media3.effect.RgbMatrix
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

enum class Tr(val label: String) { CUT("Cắt thẳng"), FADE("Mờ qua đen"), SLIDE("Trượt vào"), ZOOM("Phóng to vào") }

data class Clip(val id: Long, val uri: Uri, val durMs: Long, val tr: Tr = Tr.FADE)

private fun ease(p: Float) = p * p * (3 - 2 * p)

/** Mờ dần vào đầu clip và/hoặc mờ dần ra cuối clip (nhân màu RGB với hệ số 0..1). */
class FadeFx(private val inUs: Long, private val outUs: Long, private val clipUs: Long) : RgbMatrix {
    private var base = -1L
    override fun getMatrix(presentationTimeUs: Long, useHdr: Boolean): FloatArray {
        if (base < 0) base = presentationTimeUs
        val t = presentationTimeUs - base
        var f = 1f
        if (inUs > 0 && t < inUs) f = minOf(f, t.toFloat() / inUs)
        if (outUs > 0 && clipUs - t < outUs) f = minOf(f, (clipUs - t).toFloat() / outUs)
        f = f.coerceIn(0f, 1f)
        return floatArrayOf(f, 0f, 0f, 0f, 0f, f, 0f, 0f, 0f, 0f, f, 0f, 0f, 0f, 0f, 1f)
    }
}

/** Trượt từ phải vào hoặc phóng to dần ở đầu clip. */
class MoveFx(private val type: Tr, private val durUs: Long) : MatrixTransformation {
    private var base = -1L
    override fun getMatrix(presentationTimeUs: Long): Matrix {
        if (base < 0) base = presentationTimeUs
        val p = ease(((presentationTimeUs - base).toFloat() / durUs).coerceIn(0f, 1f))
        val m = Matrix()
        if (type == Tr.SLIDE) m.postTranslate(2f * (1f - p), 0f)
        else m.postScale(0.3f + 0.7f * p, 0.3f + 0.7f * p)
        return m
    }
}

fun durationOf(ctx: Context, uri: Uri): Long = runCatching {
    MediaMetadataRetriever().run {
        try {
            setDataSource(ctx, uri)
            extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLong() ?: 0L
        } finally { release() }
    }
}.getOrDefault(0L)

fun saveToMovies(ctx: Context, file: File): Boolean = runCatching {
    val values = ContentValues().apply {
        put(MediaStore.Video.Media.DISPLAY_NAME, "Ghep_${System.currentTimeMillis()}.mp4")
        put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
        put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/VideoGhep")
    }
    val uri = ctx.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)!!
    ctx.contentResolver.openOutputStream(uri)!!.use { out -> file.inputStream().use { it.copyTo(out) } }
    true
}.getOrDefault(false)

fun fmt(ms: Long) = "%d:%02d".format(ms / 60000, ms / 1000 % 60)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { Surface(Modifier.fillMaxSize()) { App() } } }
    }
}

@Composable
fun Thumb(uri: Uri) {
    val ctx = LocalContext.current
    val bmp by produceState<Bitmap?>(null, uri) {
        value = withContext(Dispatchers.IO) {
            runCatching {
                MediaMetadataRetriever().run {
                    try { setDataSource(ctx, uri); getFrameAtTime(0L) } finally { release() }
                }
            }.getOrNull()
        }
    }
    Box(Modifier.size(72.dp).background(Color.DarkGray)) {
        bmp?.let { Image(it.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
    }
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val clips = remember { mutableStateListOf<Clip>() }
    var seconds by remember { mutableFloatStateOf(1f) }
    var status by remember { mutableStateOf("Bấm \"Thêm video\" để bắt đầu") }
    var busy by remember { mutableStateOf(false) }
    var progress by remember { mutableIntStateOf(0) }
    var nextId by remember { mutableLongStateOf(0L) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickMultipleVisualMedia()) { uris ->
        scope.launch {
            for (u in uris) {
                val d = withContext(Dispatchers.IO) { durationOf(ctx, u) }
                clips.add(Clip(nextId++, u, d))
            }
        }
    }

    fun startExport() {
        val d = (seconds * 1_000_000).toLong()
        val items = clips.mapIndexed { i, c ->
            val clipUs = c.durMs * 1000
            val dd = maxOf(1L, minOf(d, clipUs / 2))
            val inTr = if (i == 0) Tr.CUT else c.tr
            val outFade = clips.getOrNull(i + 1)?.tr == Tr.FADE
            val fx = mutableListOf<Effect>()
            if (inTr == Tr.FADE || outFade)
                fx.add(FadeFx(if (inTr == Tr.FADE) dd else 0L, if (outFade) dd else 0L, clipUs))
            if (inTr == Tr.SLIDE || inTr == Tr.ZOOM) fx.add(MoveFx(inTr, dd))
            EditedMediaItem.Builder(MediaItem.fromUri(c.uri))
                .setEffects(Effects(emptyList(), fx))
                .build()
        }
        val out = File(ctx.cacheDir, "ghep.mp4").also { it.delete() }
        val comp = Composition.Builder(listOf(EditedMediaItemSequence(items)))
            .experimentalSetForceAudioTrack(true)
            .build()
        busy = true; progress = 0; status = "Đang xuất video..."
        val transformer = Transformer.Builder(ctx)
            .setVideoMimeType(MimeTypes.VIDEO_H264)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    scope.launch {
                        val ok = withContext(Dispatchers.IO) { saveToMovies(ctx, out) }
                        busy = false
                        status = if (ok) "Xong! Video nằm trong thư viện (Movies/VideoGhep)" else "Lưu video thất bại"
                    }
                }
                override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                    busy = false
                    status = "Lỗi: ${exportException.message}"
                }
            }).build()
        transformer.start(comp, out.absolutePath)
        scope.launch {
            val h = ProgressHolder()
            while (busy) {
                if (transformer.getProgress(h) == Transformer.PROGRESS_STATE_AVAILABLE) progress = h.progress
                delay(300)
            }
        }
    }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Ghép video", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(8.dp))
        Button(
            onClick = { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)) },
            enabled = !busy
        ) { Text("+ Thêm video") }

        LazyColumn(Modifier.weight(1f).padding(vertical = 8.dp)) {
            itemsIndexed(clips, key = { _, c -> c.id }) { i, c ->
                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Thumb(c.uri)
                    Column(Modifier.weight(1f).padding(horizontal = 8.dp)) {
                        Text("Clip ${i + 1} · ${fmt(c.durMs)}")
                        if (i > 0) TextButton(onClick = {
                            val all = Tr.values()
                            clips[i] = c.copy(tr = all[(c.tr.ordinal + 1) % all.size])
                        }) { Text("Chuyển cảnh: ${c.tr.label}") }
                    }
                    TextButton(onClick = { if (i > 0) clips.add(i - 1, clips.removeAt(i)) }) { Text("▲") }
                    TextButton(onClick = { if (i < clips.lastIndex) clips.add(i + 1, clips.removeAt(i)) }) { Text("▼") }
                    TextButton(onClick = { clips.removeAt(i) }) { Text("✕") }
                }
            }
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Thời lượng chuyển cảnh: ")
            listOf(0.5f, 1f, 1.5f).forEach {
                FilterChip(
                    selected = seconds == it, onClick = { seconds = it },
                    label = { Text("${it}s") }, modifier = Modifier.padding(end = 4.dp)
                )
            }
        }
        Spacer(Modifier.height(8.dp))
        Button(
            onClick = { startExport() },
            enabled = clips.size >= 2 && !busy,
            modifier = Modifier.fillMaxWidth()
        ) { Text("Xuất video") }
        if (busy) LinearProgressIndicator(progress = { progress / 100f }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp))
        Text(status, Modifier.padding(top = 8.dp))
    }
}
